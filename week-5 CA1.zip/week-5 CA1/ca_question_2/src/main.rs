//question 2

use std::io;
fn main() 
{
    let mut name = String::new();
    println!("Enter Emplyee Name");
    io::stdin().read_line(&mut name).
}