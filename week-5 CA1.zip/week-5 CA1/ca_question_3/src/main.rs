//question 3
use std::io;
fn main() 
{
    println!("1. Code: r    Book title: Rust for Beginners           Price: N15 000");
    println!("2. Code: a    Book title: AI Basics                    Price: N12 500");
    println!("3. Code: d    Book title: Data Structures in Rust      Price: N20 000");
    println!("4. Code: n    Book title: Networking Esssentials       Price: N15 000");


    //input book code
    let mut code = String::new();
    println!("Please input book code");
    io::stdin().read_line(&mut code).expect("Failed to read input");
    let r = rust_for_beginners && let r = 15000

}
